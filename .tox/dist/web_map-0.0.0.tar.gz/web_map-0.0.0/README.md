# film_map
 Film_map is a project that creates web map of films based on names, locations and year of film producing.
## Desription
 It utilizes python with a few module such as folium, geopy, pandas and few other, as well as some html knowledge. Main functionality is based on getting films info from files and finding their coordinates. This option can take quite a lot time so I recommend using already preprocessed file from project.
## Installation
 You can use simple git clone command in your directory to download project.
 ```bash
 git clone git@github.com:codefloww/film_map.git
 ```
 There is possible need in ssh token in case of problems with downloading
 Also you can install this project using pip install
 ```bash
 pip install -e git+https://github.com/codefloww/film_map#egg=film_map
 ```
 You also need to install dependencies for module after entering in project directory
 ```bash
 pip install -r requirements.txt
 ```
## Usage
 Use the project via terminal
 If you're in project directory:
 ```bash
 python src/web_map/main.py -h
 ```
 There are few options which you can use(info by -h or --help)
 Also you can use the package manager pip to use functions for project module
 ```bash
 pip install web-map
 ```
 ```python
 import web_map
 web_map.<main or create_file>.<functionname>(*args, **kwargs)
 ```
## Contributing
 I'll be very happy to have any feedback. Pull requests are welcome. There is a lot of possible improvment to this project. For more comfortable contribution there are provided some tests tools.
## Tests
![Tests](https://github.com/codefloww/film_map/actions/workflows/tests.yml/badge.svg)
 In case you want to use tests for this project, you need to install some packages additionaly to installing process.
 ```bash
 pip install -r requirements_dev.txt
 ```
 You can use pytest, mypy, flake8 or tox for testing this project. 
 ```bash
 mypy src
 pytest
 flake8 src
 tox
 ```
 As far as I know, this project should correctly work with python3.8 and newer. I'll be greatful for further testing.
## License
 [MIT]
 (https://choosealicense.com/licenses/mit/)

